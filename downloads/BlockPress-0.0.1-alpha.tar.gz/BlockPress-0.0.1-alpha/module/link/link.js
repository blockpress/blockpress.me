/* Not a content module. The simplest form of menuitem. */
function link_menuitem(args) {
  return args;
}
